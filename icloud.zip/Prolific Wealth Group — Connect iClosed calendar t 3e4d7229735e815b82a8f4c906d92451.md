# Prolific Wealth Group — Connect iClosed calendar to GHL (contacts + bookings)

Client: Prolific Wealth Group (https://app.notion.com/p/Prolific-Wealth-Group-3bbd7229735e8022947df46cf92b99ac?pvs=21)
Status: In Progress
Priority: P0 Same Day
Type: Feature Request
Assignee: Fahad Sami
Created Date: September 23, 2026
Due Date: September 28, 2026
Related Project: Prolific Wealth Group — Constraint Funding System (https://app.notion.com/p/Prolific-Wealth-Group-Constraint-Funding-System-3bbd7229735e81a79dabd38e6d32fce6?pvs=21)
Last Edited Time: September 28, 2026 8:37 PM

## Why

Branden books sales calls through **iClosed**, not the GHL calendar. He's keeping it because it pre-qualifies prospects before they can book. Everything we built starts from a GHL booking: reminders, no-show handling, contract → payment → kickoff → Day 90 → continuity, Slack alerts and the portal's Today's Calls screen. **An iClosed booking currently triggers none of it**, which is why contacts are being added manually.

Decision (23 Sep, Hassaan): keep iClosed and bridge it into GHL.

Sources: [‣](https://app.notion.com/p/3e3d7229735e818ba571cc673d74d633?pvs=21) · [Call Prep — Branden, Thu 24 Sep 2026 (handover + onboarding + Loom)](https://app.notion.com/p/Call-Prep-Branden-Thu-24-Sep-2026-handover-onboarding-Loom-3e4d7229735e81c4a809da29669085e3?pvs=21)

## 🔴 Update 28 Sep: the PLAN is needed TONIGHT before the Branden call (00:15 PKT)

On the 24 Sep call Hassaan promised Branden the iClosed integration plan "by tomorrow" (Fri 25 Sep). It is overdue. The build can wait for access. **The plan cannot.**

**By 23:00 PKT tonight, write in this ticket:**

1. The chosen approach: mirror calendar in GHL, or custom fields plus pipeline stage. Pick the one that keeps the existing reminder workflows unchanged, and say why.
2. The iClosed events and fields mapped to GHL (a table).
3. How duplicates are avoided (match on email, then phone).
4. What iClosed checks before booking vs what our scoring checks, and any overlap.
5. **The exact access and info Hassaan must get from Branden on tonight's call:** admin role or invite, the list of event types, and anything else.
6. A build date counted from when access arrives (2 business days).

Then set the status to Internal Review for Hassaan.

## ⏸ Still waiting on the client (for the build, not the plan)

We need **admin access to Branden's iClosed account** (to set up the webhook), and a list of the iClosed event types he uses. Requested from Branden on 23 Sep.

## What to build

Use **our n8n**, not Zapier. iClosed documents a GHL connection via Zapier/webhooks, and we already run n8n for PWG.

1. **iClosed webhooks → n8n**, for these events:
    - Form submitted / contact created
    - Call booked
    - Call rescheduled
    - Call cancelled
    - Outcome, if iClosed exposes it (no-show / completed)
2. **n8n → GHL**:
    - **Find or create the contact.** Match on email first, then phone. **No duplicates**: many of these people already exist from the PWG application.
    - Map the iClosed pre-qualification answers into GHL custom fields.
    - Move the opportunity to the **Booked** stage and record the appointment time, timezone and assigned closer.
    - On reschedule: update the time, and make sure the reminders re-time. On cancel: move the stage and stop the reminders.
3. **Everything downstream must fire** exactly as it does for a GHL booking: reminders, Slack "booked appointments" alert, portal Today's Calls, pre-call brief, and after the call, contract → payment → kickoff.
4. **Only real leads.** Apply the same rule as the contact clean-up ticket.

## Decide and document here

- Where the "source of truth" booking lives (iClosed), and how GHL shows it: a GHL appointment on a mirror calendar, or custom fields plus a pipeline stage. Pick the option that keeps the existing reminder workflows working unchanged.
- What iClosed checks before booking vs what our scoring checks. List any overlap for Hassaan.

## Done when

- [ ]  Test booking in iClosed → contact created/updated in GHL (no duplicate) → stage = Booked
- [ ]  Reminders fire at the right times, in the lead's timezone
- [ ]  Reschedule → new time reflected, reminders re-timed
- [ ]  Cancel → stage updated, reminders stop
- [ ]  Slack booked alert + portal Today's Calls show the booking
- [ ]  Completed call → contract flow triggers
- [ ]  Mapping documented here and added to Branden's user guide

## Due

2 business days after iClosed access arrives. The date is provisional until then.